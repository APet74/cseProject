/* Phase III (DDL statements) 
/* Assignment 4 - (Phase III) -DML statements
Author(s):
Date:
Instructions: 
	- Include your queries to as per the assignment.
	- You can add any extra queries for testing, but as a bare minimum
	   it is expected that you complete queries for all cases mentioned
	   in the handout for full-credit.   
*/