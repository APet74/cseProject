package com.airamerica;

import java.util.Date;

public class OffSeasonTickets extends Tickets {
	private Date seasonStartDate, seasonEndDate;
	private float rebate;
	public OffSeasonTickets(String code, String productType, Airports depAirportCode, Airports arrAirportCode,
			Date depTime, Date arrTime, String flightNo, String flightClass, String aircraftType, Date seasonStartDate,
			Date seasonEndDate, float rebate) {
		super(code, productType, depAirportCode, arrAirportCode, depTime, arrTime, flightNo, flightClass, aircraftType);
		this.seasonStartDate = seasonStartDate;
		this.seasonEndDate = seasonEndDate;
		this.rebate = rebate;
	}
	public Date getSeasonStartDate() {
		return seasonStartDate;
	}
	public void setSeasonStartDate(Date seasonStartDate) {
		this.seasonStartDate = seasonStartDate;
	}
	public Date getSeasonEndDate() {
		return seasonEndDate;
	}
	public void setSeasonEndDate(Date seasonEndDate) {
		this.seasonEndDate = seasonEndDate;
	}
	public float getRebate() {
		return rebate;
	}
	public void setRebate(float rebate) {
		this.rebate = rebate;
	}
	
	
	
}
