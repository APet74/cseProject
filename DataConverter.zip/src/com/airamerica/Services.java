package com.airamerica;

public abstract class Services extends Products {
	
	public Services(String code, String productType) {
		super(code, productType);
	}

}
