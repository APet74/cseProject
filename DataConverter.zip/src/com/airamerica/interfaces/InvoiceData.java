package com.airamerica.interfaces;

/* Assignment 5 - (Phase IV) */
/* Replace this file with one attached in Blackboard for (Assignment-5)*/
public class InvoiceData {

}
